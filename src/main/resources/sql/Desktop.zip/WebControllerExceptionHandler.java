package com.pangmaobao.iou.web.bms.handler;

import com.alibaba.fastjson.JSONObject;
import com.pangmaobao.iou.service.constant.ResCodeEnum;
import com.pangmaobao.iou.service.exception.ServiceException;
import com.pangmaobao.iou.web.bms.WebDTO;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;

import java.util.List;

/**
 * Created by qiong.peng on 2017/4/24.
 * web controller aspect
 */
@Component
@Aspect
public class WebControllerExceptionHandler {
    private static final Logger logger = LogManager.getLogger(WebControllerExceptionHandler.class);

    /**
     * 匹配com.pangmaobao.iou.web.bms.controller包及其子包下的所有类的所有方法
     * 定义一个切点
     */
    @Pointcut("execution(* com.pangmaobao.iou.web.bms.controller..*.*(..))")
    public void webIouBmsControllerPointcut(){
        // 定义一个切点
    }

    /**
     * 环绕通知
     * @param proceedingJoinPoint proceedingJoinPoint
     * @return string
     */
    @Around("webIouBmsControllerPointcut()&&@annotation(org.springframework.web.bind.annotation.ResponseBody)")
    public String doAroundAdvice(ProceedingJoinPoint proceedingJoinPoint) throws Throwable {
        logger.info("切面[doAroundAdvice]方法[" + proceedingJoinPoint.getSignature().getName() + "]执行");
        WebDTO<Object> dto = new WebDTO<>();
        String result = null;
        try {
            // 方法的参数数组
            Object[] args = proceedingJoinPoint.getArgs();
            BindingResult bindingResult = null;
            for (Object arg : args) {
                if(arg instanceof BindingResult){// 判断参数是否是BindingResult类型
                    if(((BindingResult) arg).hasErrors()){// 如果是，则判断是否有错误
                        bindingResult = (BindingResult) arg;// 有错误，则将参数指向bindingResult,并退出循环
                        break;
                    }
                }
            }
            if (bindingResult != null && bindingResult.hasErrors()) {// 判断是否有参数错误
                catchValidateError(bindingResult, dto);
            } else {
                //调用执行目标方法
                result = (String) proceedingJoinPoint.proceed();
            }
        } catch (ServiceException e) {
            logger.error("业务异常，异常信息：", e);
            dto.setResCode(e.getCode());
            dto.setResMsg(e.getMessage());
        } catch (Exception e) {
            logger.error("系统异常，异常信息：", e);
            dto.setResCodeEnum(ResCodeEnum.SYSTEM_EXCEPTION);
        }
        return StringUtils.isBlank(result) ? JSONObject.toJSONString(dto) : result;
    }

    /**
     * 处理BindingResult参数异常,只传出第一个错误（暂不抛出多个参数错误信息）
     * @param bindingResult bindingResult
     * @param dto dto
     */
    private void catchValidateError(BindingResult bindingResult, WebDTO<Object> dto) {
        List<ObjectError> list = bindingResult.getAllErrors();
        ObjectError objectError = list.get(0);
        dto.setResCode(ResCodeEnum.PARAM_EXCEPTION.getCode());
        dto.setResMsg(objectError.getDefaultMessage());
        logger.error("ObjectName=" + objectError.getObjectName() + ",code=" + objectError.getCode() + ",DefaultMessage=" + objectError.getDefaultMessage());
    }

}
