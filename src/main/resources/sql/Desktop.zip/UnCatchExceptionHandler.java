package com.pangmaobao.iou.web.bms.handler;

import com.alibaba.fastjson.JSONObject;
import com.pangmaobao.iou.web.bms.WebDTO;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by qiong.peng on 2017/4/24.
 * 处理未捕获异常
 */
@ControllerAdvice
public class UnCatchExceptionHandler {
    private static final Logger logger = LogManager.getLogger(UnCatchExceptionHandler.class);

    private static final String DEFAULT_ERROR_VIEW = "/error/error";

    /**
     * 捕获异常类型为exception的异常
     * @param request request
     * @param e exception
     * @return model and view
     */
    @ExceptionHandler(value = Exception.class)
    @ResponseBody
    public String resolveException(HttpServletRequest request, Exception e){
        logger.error("访问url[" + request.getRequestURL() + "]出错，错误信息：", e);
//        ModelAndView mav = new ModelAndView();
//        mav.addObject("exception", e);
//        mav.setViewName(DEFAULT_ERROR_VIEW);
        WebDTO<Object> dto = new WebDTO();
        dto.put("resMsg", e.getMessage());
        return JSONObject.toJSONString(dto);
    }

}
