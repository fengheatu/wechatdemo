package com.pangmaobao.iou.web.bms;

import com.pangmaobao.iou.service.constant.ResCodeEnum;

import java.util.HashMap;

/**
 * 前端数据返回model
 * Created by s.han on 2017/4/13.
 */
public class WebDTO<T> extends HashMap<String, Object> {
    //返回码
    private String resCode;
    //返回码描述
    private String resMsg;
    //具体数据
    private T data;
    //总记录数
    private Long total;
    //总页数
    private int totalPages;

    public String getResCode() {
        return this.resCode;
    }

    public void setResCode(String resCode) {
        this.resCode = resCode;
        put("resCode", resCode);
    }

    public String getResMsg() {
        return this.resMsg;
    }

    public void setResMsg(String resMsg) {
        this.resMsg = resMsg;
        put("resMsg", resMsg);
    }

    public T getData() {
        return this.data;
    }

    public void setData(T data) {
        this.data = data;
        put("data", data);
    }

    public Long getTotal() {
        return this.total;
    }

    public void setTotal(Long total) {
        this.total = total;
        put("total", total);
    }

    public int getTotalPages() {
        return this.totalPages;
    }

    public void setTotalPages(int totalPages) {
        this.totalPages = totalPages;
        put("totalPages", totalPages);
    }

    public void setResCodeEnum(ResCodeEnum resCodeEnum) {
        setResCode(resCodeEnum.getCode());
        setResMsg(resCodeEnum.getMsg());
    }

}
